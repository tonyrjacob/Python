num1 = 5
num2 = 2

floor1= num1//num2
print(floor1)
modu1 =num1%num2
print(modu1)
pow1 = num1**num2
print(pow1)
