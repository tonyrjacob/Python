instructor = input("Enter the prof's name: ")
subject = input("Enter the subject name: ")
term = input("Enter the term: ")
#print(instructor, "will teach", subject, "in", term)
#print(instructor, "will teach", subject, "in", term )
#print ('{}will teach{}in{}'.format (instructor, subject, term))
print ('{1} will be taught in {2} by {0}'.format (instructor, subject, term))
#, sep=';',end='***'
