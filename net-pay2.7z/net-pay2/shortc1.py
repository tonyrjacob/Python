st1 = 0
num1 =5
st1+=num1 # a short cut of st1 = st1 + num1
print(st1)
#st1/= num1 # a short cut of st1 = st1 / num1
print()

