#author:Kyle
import random

t1=(10,20,30,40,50)
list1=list(t1)
print(t1)

random.shuffle(list1)
t2=tuple(list1)
print(t2)
