grades =(4,5,66,78)
for i in enumerate(grades):
    print (i, i[0],i[1])
