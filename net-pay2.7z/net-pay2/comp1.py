#comparison operators e.g. < > == <=  >=  !=
num1 = 6
num2 = 7
st= "ab"
st2 ="ab"
print (num1==num2)
print (num1>num2)
print (num1<num2)
print (st<st2)
print (st!=st2)


