import math
num = 4.12734567
print (" my number is ", num)
print(" the formatted number "+"{:5.2f}".format(num))
x=math.modf(5.4)
print (x[0])
