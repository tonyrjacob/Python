saying="""An eye for eye only ends up making the whole world blind.
Where there is love there is life.
In a gentle way, you can shake the world."""
print(saying)
print()
fedTax , stateTax , countyTax = 6, 8, 11

print (fedTax , stateTax , countyTax)
print()
fedTax = stateTax = countyTax = 10
print (fedTax , stateTax , countyTax)

