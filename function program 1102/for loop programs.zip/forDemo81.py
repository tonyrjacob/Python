for i in range(1, 10, 3):
    print(i)
print('The for loop is over')