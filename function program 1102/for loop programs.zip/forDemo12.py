for letter in 'English':
    print ('The current Letter is :', letter)
print('\nthank you!')

for server in ['ibm','lenovo','hp','dell']:
    print ('The current Letter is :', server)
print('\nthank you!')

for product in ('fan','ac','washer','stove'):
    print ('The current Letter is :', product)
print('\nthank you!')