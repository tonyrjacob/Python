for i in range(1, 5):
    if i==3:
        continue# skips the current iteration
    print (i)# does not get executed when i =3
print('The for loop is over')