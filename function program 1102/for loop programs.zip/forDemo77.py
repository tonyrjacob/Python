for letter in 'Python':
    if letter == 'h': # letter = P, y ,t, h
        continue # skipping the current iteration where letter == 'h', do not print inl ine 4
    print (letter)
print ('thank you')