
i=0
while i < 5:
    num= int(input("enter a number: "))
    if num == 33:
        break
    else:print("the num is ",num)
print ('quit and num is ',num)
