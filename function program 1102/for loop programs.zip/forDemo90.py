myName = ('k','a','r','i','m') # you can replace this with strings , list or range
for i in myName:# range return numbers from 1 to 4 not including 5
    if i=='r':
        break
print('The for loop is over')