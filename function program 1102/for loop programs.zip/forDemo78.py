for letter in 'Python':
    if letter == 'h':
        break
    print (letter)
print ('thank you')

hours,rate, tax =35, 21.5, 0.13
